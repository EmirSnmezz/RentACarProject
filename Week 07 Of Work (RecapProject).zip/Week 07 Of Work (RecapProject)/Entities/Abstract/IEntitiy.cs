﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Abstract
{
    // IENTİTY'i implement eden bir class bir veritabanı tablosudur.Yani IEntity interface'i, concrete klasöründeki classların bir veritabanın tablosu olduğunu bize söylemesi için tamamen işaretçi olması amacıyla oluşturulmuştur (implement edeceği için)
    public interface IEntitiy
    {

    }
}
