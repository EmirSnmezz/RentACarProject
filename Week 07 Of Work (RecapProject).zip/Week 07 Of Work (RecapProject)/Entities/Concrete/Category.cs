﻿using Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Concrete
{
    public class Category:IEntitiy
    {
        //Çıplak Class Kalmasın -> Eğer Ki Herhangi Bir Class Herhangi Bir İnheritance ya da İmplementasyon almıyorsa İleride Nesnellik Zafiyeti Yaşayacağız Demektir Bu Yüzden Hiçbir Class Çıplak Kalmamalı
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }    
        





    }
}
