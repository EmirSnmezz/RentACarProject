﻿using Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Concrete

// Public erişim belirleyicisi sayesinde ilgili classa diğer katmanlar da ulaşabilsin demektir

// Bir classın default erişim belirleyicisi Bilinenin aksine protected değildir.Internal'dir. Internal erişim belirleyicisi sadece ilgili paket/katman içerisindeki katman elemanları tarafından erişilebilsin demektir
{
    public class Product:IEntitiy
    {

        public int ProductID { get; set; }
        public int CategoryID { get; set; }
        public string ProductName { get; set; }
        public short UnitsInStock { get; set; }
        public decimal UntiPrice { get; set; }


    }
}
