﻿using Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Abstract
{
    public interface IProductDal // Product' la ilgili veri tabanında yapacağımız işleri/operasyonları içeren interface'dir.
    {
        // I -> Interface 

        // Product -> Entity katmanında interface'e karşılık gelen tablo 

        // DAL -> Data Access Layer -> Hangi Katmanın Nesnesi/Classı olduğunu anlatırız
        /*
         İş yapan classların herzaman önce interface'i oluşturulur daha sonra iş yapan class interface'den implementasyon alır ve iş yapan classlar bu şekilde türetilmelidir.
         */
        List<Product> GetAll(); 
        void Add (Product product);
        void Delete (Product product);  
        void Update (Product product);
        List<Product> GetAllCategory(int categoryId); // Ürünleri Kategoriye göre listelemek için kullanılacak method bu methoddur.






    }
}
