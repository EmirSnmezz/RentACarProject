﻿using DataAccess.Abstract;
using NuGet;
using DataAccess.Abstract;
using DataAccess.Concrete;
using Business.Abstract;
using Business.Concrete;
using DataAccess.Concrete.InMemory;
using System.Xml.Schema;

namespace ConsoleUI
{
    public class Program
    {
        static void Main(string[] args)
        {
            ProductManager productManager = new ProductManager(new InMemoryProductDal()) ; // interfaceler newlenemediği için ve implement alan classlar implement aldıkları classların referanslarını tutabildiği için inMemoryProductDal'ı gönderdik.

            foreach (var product in productManager.GetAll() )
            {
                Console.WriteLine(product.ProductName);
            }
        }
    }
}