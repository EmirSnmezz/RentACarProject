﻿namespace ConsoleUıTest
{
    public class Class1
    {

    }
}