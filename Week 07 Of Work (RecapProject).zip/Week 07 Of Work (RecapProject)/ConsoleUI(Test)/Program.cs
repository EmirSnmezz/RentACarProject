﻿using System;
using Business.Concrete;
using DataAccess.Concrete;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI_Test_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ProductMananger productManager = new ProductManage(new InMemoryProductDal());
            {

            };
        }
    }
}
